#Logistic Regression
#Who survived the sinking of the Titanic

library(titanic)
#sibsp = No. of siblings/spouses aboard
#Parch = No. of parents/children aboard
# Embarked: C = Cherbourg; Q = Queenstown; S = Southampton

data.raw = titanic_train
dim(data.raw) #shows me the number of rows and columns in the dataset
#891 rows and 12 columns
length(data.raw$Pclass) #Number of datapoints -> 891
#This data has blanks. Let's convert the blanks into "NA"
#"NA" is different from blanks
data.raw[data.raw==""] <- NA #Not in quotes NA->Not a string NA
#NA is an R standardized variable that means Not Available

#If there is a case of too many NA's
#check for missing values using sapply() and then colSums command
sapply(data.raw, function(x) sum(is.na(x)))
colSums(is.na(data.raw)) #sums up the NA columns

#How many unqiue values are there in each column
sapply(data.raw, function(x) length(unique(x)))

#A few basic ratios
overall_survival_rate = sum(data.raw$Survived == 1)/length(data.raw$Survived) #0.383838...
#38% of the people survived; 62% died
cat("Fraction of people who survived = ", format(overall_survival_rate, digits = 3))

male_survival_rate = sum((data.raw$Survived == 1) & (data.raw$Sex == "male"))/sum(data.raw$Sex == "male")
#0.1889... 19% survived; 81% died
cat("Fraction of males who survived = ", format(male_survival_rate, digits = 3))

female_survival_rate = sum((data.raw$Survived == 1) & (data.raw$Sex == "female"))/sum(data.raw$Sex == "female")
#0.7420... 74% survived; 26% died
cat("Fraction of females who survived = ", format(female_survival_rate, digits = 3))

class1_survival_rate = sum((data.raw$Survived==1) & (data.raw$Pclass==1))/sum(data.raw$Pclass==1)
cat("Fraction of first class passengers who survived = ", format(class1_survival_rate, digits = 3))

class2_survival_rate = sum((data.raw$Survived==1) & (data.raw$Pclass==2))/sum(data.raw$Pclass==2)
cat("Fraction of second class passengers who survived = ", format(class2_survival_rate, digits = 3))

class3_survival_rate = sum((data.raw$Survived==1) & (data.raw$Pclass==3))/sum(data.raw$Pclass==3)
cat("Fraction of third class passengers who survived = ", format(class3_survival_rate, digits = 3))

data.T = na.omit(subset(data.raw,select=c(2,3,5)))
#create a subset od data.raw with only columns 2,3,5 that is 
#Survived, Pclass and Sex
#na.omit throws out any na data. There are no na data in columns 2,3,5
table(data.T)
#It will give me two 2 by 3 tables of males and females surviving

#prop.table will give proportions instead of raw numbers
#prop.table only works on numerical values
prop.table(table(data.raw$Survived))
prop.table(table(data.raw$Sex))
prop.table(table(data.raw$Pclass))

#-------------Cleaning and analysing data done-------------#

# Let's drop the columns that we know we are not going to use
# 1-PassengerId, 4=Name, 9=Ticket, 11=Cabin
data.new = subset(data.raw,select=c(2,3,5,6,7,8,10,12))

#to check correlations, I'll convert the factors (male, female etc)
# into indicator variables using the "dummies" package
# install.packages("dummies")
library(dummies)
data.indicator = subset(data.new, select=c(1:7))
data.indicator$Sex = dummy(data.new$Sex)
#male=1; female=0
cor(data.indicator)
#correlation ranges from 0 to 1 or -1 to 0 (depending on incremental or decremental)
#Closer the correlation to 1 (or -1), higher dependency


#To see how the factors will be "dummified" (turned into indicators) by R:
is.factor(data.new$Sex) #Is this variable a factor? FALSE
contrasts(factor(data.new$Sex)) #show how the factor will be converted to an indicator
#creates a dummy variable male which will give female=0 and male=1
levels(factor(data.new$Embarked)) #What are the levels of this factor? "C" "Q" and "S"
contrasts(factor(data.new$Embarked))
#Two indicator variables Q and S. For C-> 0 0; Q-> 1 0; S-> 0 1

#Logistic Regression starts from here
model <- glm(Survived~.,family=binomial(link = 'logit'),data=data.new)
#glm: generalized linear modelling
summary(model)


#use the anova function to compare the addition of each variable 
anova(model, test="chisq")

# create s small dataset containing only the rows and columns that we will use in our model
data.small <- na.omit(subset(data.new,select=c(1,2,3,4,5)))
model <- glm(Survived~.,family=binomial(link = 'logit'),data=data.small)
summary(model)
confint(model) #confidence intervals of the coefficients

#--------PLOT--------#
plot(model)
#The residuals are low where we predicted them to survive and they did
#OR we predicted them to die and they did. Hence they are closely placed, dense and with high probability 
#residuals are high for where we predicted it wrong.
#Performance is reasonable



#---------------------PREDICTIONS VS ACTUAL-----------------------------
#Let's call a "hit" when predicted>50% matches survived=1
#and predicted<50% matches survived=0

#model$fitted is the predicted probability of survival
#When probability is above 0.5, you multiply it by 2, and the value is above 1
#which gets truncated to 1. Similarly when probability is less than 0.5, and the
#value is multipled by 2, the value will be less than 1 and truncating it will give 0
y = data.small$Survived - trunc(2*model$fitted)#0 or 1 survival rate
#Subtract the predicted 0 or 1 with the actual 0 or 1

hits= sum(y==0)
hitratio=hits/length(y)

#hits  577L
#hitratio 0.8081... or 80.81%

#we can express each of the coefficients as an odds ratio:
exp(coef(model))

#Odds Ratio with its 95% confidence interval
exp(cbind(OddsRatio = coef(model), confint(model)))
